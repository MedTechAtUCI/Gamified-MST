import json
import os
import boto3
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ.get("DYNAMO_TABLE", "metrics-table"))
state_table = dynamodb.Table(os.environ.get("USER_STATE_TABLE", "user-state-table"))


def count_completed_sessions(user_id):
    """
    Count total completed sessions for a user across all session records.
    """
    try:
        # Query all sessions for this user
        response = state_table.query(
            KeyConditionExpression="userId = :uid",
            ExpressionAttributeValues={":uid": user_id},
            ProjectionExpression="sessions"
        )
        
        completed_count = 0
        for item in response.get("Items", []):
            sessions = item.get("sessions", [])
            # Count sessions marked as completed
            completed_count += sum(1 for s in sessions if s.get("completed"))
        
        return completed_count
    except Exception as e:
        print(f"Error counting completed sessions: {e}")
        return 0


def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
    }

    try:
        # Handle API Gateway or direct test
        if "body" in event:
            payload = json.loads(event["body"])
        else:
            payload = event
        
        # Extract request parameters
        user_id = payload.get("user_id")
        session_id = payload.get("session_id")
        curr_level = payload.get("current_level")
        game_set = payload.get("set")
        session_completed = payload.get("session_completed", False)
        game_type = payload.get("game_type", "G")  # Default to 'G' (gamified)

        # Append the game type suffix to make the session key distinct
        if session_id and f"#{game_type}" not in str(session_id):
            session_id = f"{session_id}#{game_type}"

        # Calculate week_of_study on backend based on completed sessions count
        # Week = (number of completed sessions) + 1
        completed_sessions_count = count_completed_sessions(user_id) if user_id else 0
        week_of_study = completed_sessions_count + 1

        # Ensure numeric fields are the correct type
        if curr_level is not None:
            curr_level = int(curr_level)
        if game_set is not None:
            game_set = int(game_set)
        else:
            game_set = 0
        if week_of_study is not None:
            week_of_study = int(week_of_study)

        participant_age = payload.get("participant_age")
        participant_gender = payload.get("participant_gender")
        participant_ethnicity = payload.get("participant_ethnicity")
        participant_race = payload.get("participant_race")
        participant_handedness = payload.get("participant_handedness")
        participant_education = payload.get("participant_education")
        participant_colorblindness = payload.get("participant_colorblindness")

        screen_size = payload.get("screen_size")
        device_type = payload.get("device_type")

        experience_quality = payload.get("experience_quality")
        test_location = payload.get("test_location")
        performance_self_rating = payload.get("performance_self_rating")
        performance_interferences = payload.get("performance_interferences")
        negative_symptoms = payload.get("negative_symptoms")

        # Ensure numeric fields are properly typed
        if participant_education is not None:
            try:
                participant_education = int(participant_education)
            except (ValueError, TypeError):
                participant_education = None

        # Ensure participant_age is an integer
        if participant_age is not None:
            participant_age = int(participant_age)

        # Ensure experience_quality is an integer
        if experience_quality is not None:
            experience_quality = int(experience_quality)  

        # Ensure performance_self is an integer
        if performance_self_rating is not None:
            performance_self_rating = int(performance_self_rating)

        # Validate age >= 18 (server-side enforcement)
        if participant_age is not None and participant_age < 18:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"error": "Participant must be 18 years or older"})
            }

        if user_id and session_id:
            # First, fetch current user state to preserve sessions array
            response = state_table.get_item(
                Key={"userId": user_id, "sessionId": session_id}
            )
            
            current_state = response.get("Item", {})
            sessions = current_state.get("sessions", [])
            
            # Build update expression and values
            update_parts = ["current_level = :lvl", "week_of_study = :week"]
            expr_values = {
                ":lvl": curr_level,
                ":week": week_of_study
            }
            
            # Always update game_set if provided (both variants send 'set' field)
            if game_set is not None:
                update_parts.append("game_set = :set")
                expr_values[":set"] = game_set

            # Always update demographics if provided
            if participant_age is not None:
                update_parts.append("participant_age = :age")
                expr_values[":age"] = participant_age

            if participant_gender:
                update_parts.append("participant_gender = :gender")
                expr_values[":gender"] = participant_gender

            if participant_ethnicity:
                update_parts.append("participant_ethnicity = :ethnicity")
                expr_values[":ethnicity"] = participant_ethnicity

            if participant_race:
                update_parts.append("participant_race = :race")
                expr_values[":race"] = participant_race
                
            if participant_handedness:
                update_parts.append("participant_handedness = :hand")
                expr_values[":hand"] = participant_handedness

            if participant_education is not None:
                update_parts.append("participant_education = :education")
                expr_values[":education"] = participant_education

            if participant_colorblindness:
                update_parts.append("participant_colorblindness = :colorblindness")
                expr_values[":colorblindness"] = participant_colorblindness

            if screen_size:
                update_parts.append("screen_size = :screen")
                expr_values[":screen"] = screen_size

            if device_type:
                update_parts.append("device_type = :device")
                expr_values[":device"] = device_type

            if game_type:
                update_parts.append("game_type = :game_type")
                expr_values[":game_type"] = game_type

            if experience_quality is not None:
                update_parts.append("experience_quality = :experience_quality")
                expr_values[":experience_quality"] = experience_quality

            if test_location:
                update_parts.append("test_location = :test_location")
                expr_values[":test_location"] = test_location

            if performance_self_rating is not None:
                update_parts.append("performance_self_rating = :performance_self_rating")
                expr_values[":performance_self_rating"] = performance_self_rating

            if performance_interferences:
                update_parts.append("performance_interferences = :performance_interferences")
                expr_values[":performance_interferences"] = performance_interferences

            if negative_symptoms:
                update_parts.append("negative_symptoms = :negative_symptoms")
                expr_values[":negative_symptoms"] = negative_symptoms
            # Always track session progress (not just at completion)
            # Update or create session record with current state
            # NECESSARY!!! If session already exists, preserve its set_number unless new one is provided
            existing_session = None
            for sess in sessions:
                if sess.get("sessionId") == session_id:
                    existing_session = sess
                    break
            
            # Use new game_set if provided, otherwise preserve existing
            final_set = game_set if game_set is not None else (existing_session.get("set_number") if existing_session else None)
            
            session_record = {
                "sessionId": session_id,
                "set_number": final_set,
                "completed": session_completed,
                "current_level": curr_level,
                "week_of_study": week_of_study
            }
            
            # Check if session already exists in array
            session_exists = False
            for i, sess in enumerate(sessions):
                if sess.get("sessionId") == session_id:
                    sessions[i] = session_record
                    session_exists = True
                    break
            
            if not session_exists:
                sessions.append(session_record)
            
            update_parts.append("sessions = :sessions")
            expr_values[":sessions"] = sessions

            state_table.update_item(
                Key={"userId": user_id, "sessionId": session_id},
                UpdateExpression="SET " + ", ".join(update_parts),
                ExpressionAttributeValues=expr_values
            )
        
        # Store trial data if included
        trials = payload.get('trials', [])
        if trials and user_id and session_id:
            with table.batch_writer() as batch:
                for trial in trials:
                    # Normalize image_id: strip CloudFront URL if present
                    image_id = trial.get("image_id", "")
                    if image_id.startswith("http"):
                        # Extract just Set#/filename part (e.g., "Set5/192a.jpg")
                        parts = image_id.split("/")
                        # Find the index of "Set#" part and take from there
                        for i, part in enumerate(parts):
                            if part.startswith("Set"):
                                image_id = "/".join(parts[i:i+2]) if i+1 < len(parts) else part
                                break
                    
                    trial_id = trial.get("trial_id", "")
                    
                    # Ensure numeric fields are properly typed
                    trial_id_int = int(trial_id) if trial_id else 0
                    reaction_time_ms = trial.get("reaction_time_ms")
                    if reaction_time_ms is not None:
                        reaction_time_ms = int(reaction_time_ms)
                    lure_bin = trial.get("lure_bin")
                    if lure_bin is not None:
                        lure_bin = int(lure_bin)
                    
                    # MST-specific fields
                    mst_type = trial.get("mst_type")
                    if mst_type is not None:
                        mst_type = int(mst_type)
                    lag = trial.get("lag")
                    if lag is not None:
                        lag = int(lag)
                    correct_resp = trial.get("correct_resp")
                    if correct_resp is not None:
                        correct_resp = int(correct_resp)
                    
                    item = {
                        "userId": user_id,
                        "session_trial": f"{session_id}#{trial_id}#{game_type}",
                        "trial_id": trial_id_int,
                        "image_id": image_id,
                        "trial_type": trial.get("trial_type"),
                        "mst_type": mst_type,
                        "lag": lag,
                        "lure_bin": lure_bin,
                        "participant_response": trial.get("participant_response"),
                        "correct_resp": correct_resp,
                        "correct": trial.get("correct"),
                        "reaction_time_ms": reaction_time_ms,
                        "timestamp": trial.get("timestamp"),
                        "game_type": game_type,
                        "participant_age": participant_age,
                        "participant_gender": participant_gender,
                        "participant_ethnicity": participant_ethnicity,
                        "participant_race": participant_race,
                        "participant_handedness": participant_handedness,
                        "participant_education": participant_education,
                        "participant_colorblindness": participant_colorblindness,
                        "device_type": device_type,
                        "screen_size": screen_size
                    }

                    batch.put_item(Item=item)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"message": "State updated successfully"})
        }

    except Exception as e:
        import traceback
        error_msg = str(e)
        traceback.print_exc()
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": error_msg, "type": type(e).__name__})
        }